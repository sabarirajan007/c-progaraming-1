/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
int main()
{
int a,b,temp;

    printf("enter the first element");
    scanf("%d",&a);
    printf("enter the second element");
    scanf("%d",&b);
    temp=a;
    temp=16;
    a=b;
    b=temp;
    printf("after swapping the value of a is %d\n",a);
    printf("after swapping the value of b is %d\n",b);
    return 0;
}
